Inside the TouchStart folder you will find the working code for each
example in Chapter 2.

In order to test, you must update the following line in index.html:

	<script type="text/javascript" src="app/TouchStart.js"> </script>

You should change "app/TouchStart.js" to "app/TouchStart-1.js" for the
first example, then update the -# number for each subsequent
example. There are files for TouchStart-1.js through
